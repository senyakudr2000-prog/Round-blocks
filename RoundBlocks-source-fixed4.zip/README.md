# RoundBlocks 1.0.1

Fabric mod for Minecraft Java 1.21.11. Adds eight rounded/hollow building blocks.

## Build

Run `gradle build` with Java 21. The remapped mod jar is produced in `build/libs/`.
Run `python3 -m pip install Pillow` and `python3 tools/make_resourcepack.py` to generate the 2048px PBR resource pack.

The PBR pack intentionally contains textures only. The block geometry/models are supplied by the mod, so the resource pack does not overwrite them with cube models.
