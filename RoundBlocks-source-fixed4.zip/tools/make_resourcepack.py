import os, json, math, random, zipfile
from PIL import Image, ImageDraw, ImageFilter
ROOT=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT=os.path.join(ROOT,'resourcepack')
TEX=os.path.join(OUT,'assets','roundblocks','textures','block')
os.makedirs(TEX,exist_ok=True)
random.seed(42)
N=2048
names=['quarter_cylinder','half_cylinder','full_cylinder','quarter_ring','half_ring','hollow_cube','round_column','round_arch_piece']
for name in names:
    # restrained warm concrete PBR base color with subtle mineral variation
    base=Image.new('RGB',(N,N)); px=base.load()
    for y in range(N):
        for x in range(N):
            n=random.gauss(0,2.0)
            vein=1.8*math.sin(x/57)+1.1*math.sin(y/91)
            v=int(max(0,min(255,146+n+vein)))
            px[x,y]=(v,int(v*.99),int(v*.95))
    d=ImageDraw.Draw(base,'RGB')
    for _ in range(700):
        x=random.randrange(N);y=random.randrange(N);r=random.randrange(1,5)
        c=random.choice([(133,130,124),(158,155,148),(170,166,158)])
        d.ellipse((x-r,y-r,x+r,y+r),fill=c)
    base.save(os.path.join(TEX,name+'.png'),optimize=True)
    # OpenGL normal map, mostly flat with subtle rough surface noise
    normal=Image.new('RGB',(N,N)); np=normal.load()
    for y in range(N):
        for x in range(N):
            q=random.randint(-2,2); np[x,y]=(128+q,128-q,254)
    normal.save(os.path.join(TEX,name+'_n.png'),optimize=True)
    # specular/roughness map: low reflectivity, high roughness
    spec=Image.new('RGB',(N,N),(24,190,0))
    spec.save(os.path.join(TEX,name+'_s.png'),optimize=True)
with open(os.path.join(OUT,'pack.mcmeta'),'w') as f:
    json.dump({'pack':{'pack_format':75,'description':'RoundBlocks PBR Materials • 2048x2048'}},f,indent=2)
# zip pack at repository root
zpath=os.path.join(ROOT,'RoundBlocks-PBR-2048.zip')
with zipfile.ZipFile(zpath,'w',zipfile.ZIP_DEFLATED) as z:
    for folder,_,fs in os.walk(OUT):
        for fn in fs:
            p=os.path.join(folder,fn); z.write(p,os.path.relpath(p,OUT))
print(zpath)
