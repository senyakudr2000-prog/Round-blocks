package dev.roundblocks;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

public class RoundBlocks implements ModInitializer {
    public static final String MOD_ID = "roundblocks";

    @Override
    public void onInitialize() {
        register("quarter_cylinder", shapeQuarter());
        register("half_cylinder", shapeHalf());
        register("full_cylinder", shapeCircle());
        register("quarter_ring", shapeQuarterRing());
        register("half_ring", shapeHalfRing());
        register("hollow_cube", shapeHollowCube());
        register("round_column", shapeCircle());
        register("round_arch_piece", shapeHalf());

        ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.BUILDING_BLOCKS).register(entries -> {
            for (String name : BLOCK_NAMES) {
                entries.accept(BuiltInRegistries.ITEM.getValue(id(name)));
            }
        });
    }

    private static final String[] BLOCK_NAMES = {
        "quarter_cylinder", "half_cylinder", "full_cylinder", "quarter_ring",
        "half_ring", "hollow_cube", "round_column", "round_arch_piece"
    };

    private static Identifier id(String name) {
        return Identifier.fromNamespaceAndPath(MOD_ID, name);
    }

    private static void register(String name, VoxelShape shape) {
        Identifier identifier = id(name);
        ResourceKey<Block> blockKey = ResourceKey.create(Registries.BLOCK, identifier);
        ResourceKey<Item> itemKey = ResourceKey.create(Registries.ITEM, identifier);

        // In 1.21.11 the registry key must be assigned before the object is constructed.
        Block block = new RoundedBlock(
            BlockBehaviour.Properties.of()
                .strength(2.0F)
                .requiresCorrectToolForDrops()
                .setId(blockKey),
            shape
        );
        Registry.register(BuiltInRegistries.BLOCK, blockKey, block);

        BlockItem blockItem = new BlockItem(block, new Item.Properties().setId(itemKey));
        Registry.register(BuiltInRegistries.ITEM, itemKey, blockItem);
    }

    private static VoxelShape shapeQuarter() {
        return sector(0, 0, 8, 8, 16, 16, 0, 90);
    }

    private static VoxelShape shapeHalf() {
        return sector(0, 0, 0, 16, 16, 16, 0, 180);
    }

    private static VoxelShape shapeCircle() {
        return sector(0, 0, 0, 16, 16, 16, 0, 360);
    }

    private static VoxelShape shapeQuarterRing() {
        return ring(0, 0, 8, 8, 16, 16, 4.0, 0, 90);
    }

    private static VoxelShape shapeHalfRing() {
        return ring(0, 0, 0, 16, 16, 16, 4.0, 0, 180);
    }

    private static VoxelShape shapeHollowCube() {
        return Shapes.or(
            Shapes.box(0, 0, 0, 0.25, 1, 1),
            Shapes.box(0.75, 0, 0, 1, 1, 1),
            Shapes.box(0.25, 0, 0, 0.75, 0.25, 1),
            Shapes.box(0.25, 0.75, 0, 0.75, 1, 1)
        );
    }

    private static VoxelShape sector(double minX, double minY, double minZ,
                                    double maxX, double maxY, double maxZ,
                                    int start, int sweep) {
        VoxelShape result = Shapes.empty();
        double cx = (minX + maxX) / 2.0;
        double cz = (minZ + maxZ) / 2.0;
        double rx = (maxX - minX) / 2.0;
        double rz = (maxZ - minZ) / 2.0;
        int steps = Math.max(8, sweep / 5);
        for (int i = 0; i < steps; i++) {
            double a = Math.toRadians(start + sweep * (double) i / steps);
            double b = Math.toRadians(start + sweep * (double) (i + 1) / steps);
            double x1 = cx + rx * Math.cos(a), z1 = cz + rz * Math.sin(a);
            double x2 = cx + rx * Math.cos(b), z2 = cz + rz * Math.sin(b);
            double x0 = Math.max(0, Math.min(cx, Math.min(x1, x2))) / 16.0;
            double x3 = Math.min(16, Math.max(cx, Math.max(x1, x2))) / 16.0;
            double z0 = Math.max(0, Math.min(cz, Math.min(z1, z2))) / 16.0;
            double z3 = Math.min(16, Math.max(cz, Math.max(z1, z2))) / 16.0;
            if (x3 > x0 && z3 > z0) {
                result = Shapes.or(result, Shapes.create(new AABB(
                    x0, minY / 16.0, z0, x3, maxY / 16.0, z3
                )));
            }
        }
        return result;
    }

    private static VoxelShape ring(double minX, double minY, double minZ,
                                   double maxX, double maxY, double maxZ,
                                   double inner, int start, int sweep) {
        VoxelShape result = Shapes.empty();
        double cx = (minX + maxX) / 2.0;
        double cz = (minZ + maxZ) / 2.0;
        double roX = (maxX - minX) / 2.0;
        double roZ = (maxZ - minZ) / 2.0;
        double riX = Math.max(0, roX - inner);
        double riZ = Math.max(0, roZ - inner);
        int steps = Math.max(8, sweep / 5);
        for (int i = 0; i < steps; i++) {
            double a = Math.toRadians(start + sweep * (double) i / steps);
            double b = Math.toRadians(start + sweep * (double) (i + 1) / steps);
            double[] xs = {cx + roX * Math.cos(a), cx + roX * Math.cos(b), cx + riX * Math.cos(a), cx + riX * Math.cos(b)};
            double[] zs = {cz + roZ * Math.sin(a), cz + roZ * Math.sin(b), cz + riZ * Math.sin(a), cz + riZ * Math.sin(b)};
            double x0 = xs[0], x1 = xs[0], z0 = zs[0], z1 = zs[0];
            for (int j = 1; j < 4; j++) {
                x0 = Math.min(x0, xs[j]); x1 = Math.max(x1, xs[j]);
                z0 = Math.min(z0, zs[j]); z1 = Math.max(z1, zs[j]);
            }
            x0 = Math.max(0, x0) / 16.0; x1 = Math.min(16, x1) / 16.0;
            z0 = Math.max(0, z0) / 16.0; z1 = Math.min(16, z1) / 16.0;
            if (x1 > x0 && z1 > z0) {
                result = Shapes.or(result, Shapes.box(x0, minY / 16.0, z0, x1, maxY / 16.0, z1));
            }
        }
        return result;
    }
}
