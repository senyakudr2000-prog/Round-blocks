# RoundBlocks

Fabric 1.21.11 mod + companion 2048px PBR resource pack generator.

## Build
Run `./gradlew build`. The GitHub workflow supplied separately also creates `RoundBlocks-PBR-2048.zip`.
Install the mod JAR in `mods/`. Put the generated resource pack ZIP in `resourcepacks/`.

## Included block IDs
`quarter_cylinder`, `half_cylinder`, `full_cylinder`, `quarter_ring`, `half_ring`,
`hollow_cube`, `round_column`, `round_arch_piece`.

The current source registers the block shapes and collision geometry. The resource-pack generator supplies the 2048px material maps and block model assets.
