package dev.roundblocks;

import net.fabricmc.api.ModInitializer;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.Registry;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.CreativeModeTabs;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;
import net.minecraft.world.phys.AABB;

public class RoundBlocks implements ModInitializer {
    public static final String MOD_ID = "roundblocks";
    private static final BlockBehaviour.Properties SETTINGS =
        BlockBehaviour.Properties.of().strength(2.0F).requiresCorrectToolForDrops();

    @Override public void onInitialize() {
        ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.BUILDING_BLOCKS).register(entries -> {
            for (String name : new String[] {"quarter_cylinder","half_cylinder","full_cylinder","quarter_ring","half_ring","hollow_cube","round_column","round_arch_piece"}) {
                entries.accept(BuiltInRegistries.ITEM.get(ResourceLocation.fromNamespaceAndPath(MOD_ID, name)));
            }
        });
        register("quarter_cylinder", shapeQuarter());
        register("half_cylinder", shapeHalf());
        register("full_cylinder", shapeCircle());
        register("quarter_ring", shapeQuarterRing());
        register("half_ring", shapeHalfRing());
        register("hollow_cube", shapeHollowCube());
        register("round_column", shapeCircle());
        register("round_arch_piece", shapeHalf());
    }

    private static void register(String name, VoxelShape shape) {
        Block block = new RoundedBlock(SETTINGS, shape);
        ResourceLocation id = ResourceLocation.fromNamespaceAndPath(MOD_ID, name);
        Registry.register(BuiltInRegistries.BLOCK, id, block);
        Registry.register(BuiltInRegistries.ITEM, id, new BlockItem(block, new Item.Properties()));
    }

    private static VoxelShape shapeQuarter() {
        return sector(0, 0, 8, 8, 16, 16, 0, 90);
    }
    private static VoxelShape shapeHalf() {
        return sector(0, 0, 0, 16, 16, 16, 0, 180);
    }
    private static VoxelShape shapeCircle() {
        return sector(0, 0, 0, 16, 16, 16, 0, 360);
    }
    private static VoxelShape shapeQuarterRing() {
        return ring(0, 0, 8, 8, 16, 16, 4.0, 0, 90);
    }
    private static VoxelShape shapeHalfRing() {
        return ring(0, 0, 0, 16, 16, 16, 4.0, 0, 180);
    }
    private static VoxelShape shapeHollowCube() {
        VoxelShape outer = Shapes.block();
        VoxelShape hole = Shapes.box(0.25, 0.25, -0.01, 0.75, 0.75, 1.01);
        // Collision is represented as four solid walls; opening passes through the block.
        return Shapes.or(
            Shapes.box(0,0,0,0.25,1,1), Shapes.box(0.75,0,0,1,1,1),
            Shapes.box(0.25,0,0,0.75,0.25,1), Shapes.box(0.25,0.75,0,0.75,1,1));
    }
    private static VoxelShape sector(double minX,double minY,double minZ,double maxX,double maxY,double maxZ,int start,int sweep) {
        VoxelShape result = Shapes.empty();
        double cx=(minX+maxX)/2, cz=(minZ+maxZ)/2, rx=(maxX-minX)/2, rz=(maxZ-minZ)/2;
        int steps=Math.max(8,sweep/5);
        for(int i=0;i<steps;i++){
            double a=Math.toRadians(start+sweep*(double)i/steps), b=Math.toRadians(start+sweep*(double)(i+1)/steps);
            double x1=cx+rx*Math.cos(a), z1=cz+rz*Math.sin(a), x2=cx+rx*Math.cos(b), z2=cz+rz*Math.sin(b);
            result=Shapes.or(result, Shapes.create(new AABB(Math.min(cx,Math.min(x1,x2))/16,minY/16,Math.min(cz,Math.min(z1,z2))/16,
                Math.max(cx,Math.max(x1,x2))/16,maxY/16,Math.max(cz,Math.max(z1,z2))/16)));
        }
        return result;
    }
    private static VoxelShape ring(double minX,double minY,double minZ,double maxX,double maxY,double maxZ,double inner,int start,int sweep) {
        VoxelShape outer=sector(minX,minY,minZ,maxX,maxY,maxZ,start,sweep);
        // Ring collision approximation: segmented annular walls.
        VoxelShape result=Shapes.empty(); double cx=(minX+maxX)/2,cz=(minZ+maxZ)/2,ro=(maxX-minX)/2,ri=ro-inner;
        int steps=Math.max(8,sweep/5);
        for(int i=0;i<steps;i++){
            double a=Math.toRadians(start+sweep*(double)i/steps),b=Math.toRadians(start+sweep*(double)(i+1)/steps);
            double[] xs={cx+ro*Math.cos(a),cx+ro*Math.cos(b),cx+ri*Math.cos(a),cx+ri*Math.cos(b)};
            double[] zs={cz+ro*Math.sin(a),cz+ro*Math.sin(b),cz+ri*Math.sin(a),cz+ri*Math.sin(b)};
            double x0=xs[0],x1=xs[0],z0=zs[0],z1=zs[0];
            for(int j=1;j<4;j++){x0=Math.min(x0,xs[j]);x1=Math.max(x1,xs[j]);z0=Math.min(z0,zs[j]);z1=Math.max(z1,zs[j]);}
            result=Shapes.or(result,Shapes.box(x0/16,minY/16,z0/16,x1/16,maxY/16,z1/16));
        }
        return result;
    }
}
